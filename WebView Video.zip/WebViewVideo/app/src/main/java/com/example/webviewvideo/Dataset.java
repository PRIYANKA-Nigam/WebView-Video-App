package com.example.webviewvideo;

public class Dataset {
    String link;

    public Dataset(String link) {
        this.link = link;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
